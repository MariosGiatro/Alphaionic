import urllib.request
from urllib.request import urlopen
import json
import pymol2
import os
import subprocess

if not os.path.exists('OriginalAlphafillModel'): #creating files for better file managment
   os.mkdir('OriginalAlphafillModel');
if not os.path.exists('SimplyFilteredCifs'):
   os.mkdir('SimplyFilteredCifs')
if not os.path.exists('NoHets'):
   os.mkdir('NoHets')
if not os.path.exists('fullyFiltered'):
   os.mkdir('fullyFiltered')
if not os.path.exists('MinimizedStructurePDB'):
   os.mkdir('MinimizedStructurePDB')

f=open('0afstructures.txt') # provide a list containing afilled ids
alist=f.read()
f.close()
aflist=alist.split('\n') #separated by enter
N=len(aflist)
for c in range (0,N):
####### READ THE CIF, download from afill db #######
    ff = urllib.request.urlopen('https://alphafill.eu/v1/aff/'+aflist[c]).read().decode('utf-8')
    d=open('./OriginalAlphafillModel/'+'Original_'+aflist[c]+'.cif','w')
    d.write(ff)                                 # save it locally
    d.close()
    f=open('./OriginalAlphafillModel/'+'Original_'+aflist[c]+'.cif','r')
    line = f.readlines()
    f.close()
    l=len(line); i=0; toWrite=[]; n=[]; ii=0; toWrite2=[]
    while i<l :
          if line[i][0:6]!="HETATM":
             toWrite.append(line[i]);
          else:
                splt=line[i].split(); s=splt[5];   ######### KEEP ONLY THE ATOMS THAT ARE ONE OF THESE METALS  #############
                if s=="ZN" or s=="FE" or s=="NA" or s=="MG" or s=="CU" or s=="K" or s=="CA" or s=="MN" or s=="CO" or s=="NI":
                   toWrite.append(line[i]); n.append(i-ii)
                elif s=='HEM':                     ######### KEEP HEME SEPARATELLY
                   toWrite2.append(line[i]); ii=ii+1
                else:
                      ii=ii+1
          i=i+1

######## READ THE JSON METADATA, afill db ##########
    url = 'https://alphafill.eu/v1/aff/'+aflist[c]+'/json'
    with urlopen(url) as response:
         body = response.read()
    mdata = json.loads(body)
    if mdata['hits']!=None:               ###### IF NO HETATAOMS, DOWNLOAD ONLY ######
        l1=len(mdata['hits'])
        grmsd=[]; lrmsd=[]; pdbid=[]; tcs=[]; homol=[]; hemeLRMSD=[]; hemeBlast=[]; hemeAsymid=[]; hemeTCS=[]; ##hemeGRMSD=[];
        for i in range (0,l1):
            if mdata['hits'][i]['transplants'] != None:
               l2=len(mdata['hits'][i]['transplants']);
               for j in range (0,l2):
                   cN=mdata['hits'][i]['transplants'][j]['compound_id']  ###### LIST THE SCORES, BLAST, VDWls, RMSDs ########
                   if cN=='ZN' or cN=='NA' or cN=='FE' or cN=='MG' or cN=='K' or cN=='NI' or cN=='MN' or cN=='CU' or cN=='CA' or cN=='CO':
                      grmsd.append(mdata['hits'][i]['global_rmsd'])
                      homol.append(mdata['hits'][i]['alignment']['identity'])
                      lrmsd.append(mdata['hits'][i]['transplants'][j]['local_rmsd'])
                      pdbid.append(mdata['hits'][i]['pdb_id']);
                      tcs.append(mdata['hits'][i]['transplants'][j]['clash']['score'])
                   if cN=='HEM':
                      hemeTCS.append(mdata['hits'][i]['transplants'][j]['clash']['score'])
                      hemeLRMSD.append(mdata['hits'][i]['transplants'][j]['local_rmsd'])
                      #hemeGRMSD.append(mdata['hits'][i]['global_rmsd'])
                      hemeBlast.append(mdata['hits'][i]['alignment']['identity'])
                      hemeAsymid.append(mdata['hits'][i]['transplants'][j]['asym_id'])

        if grmsd!=[]: ## if there are metalions
            L=len(grmsd); i=0;
            while i<L:
                 if homol[i]<0.7 or grmsd[i]>0.5:  ########## THRESHOLDS TO RETAIN ONLY CONFIDENT ADDITIONS ############
                    if lrmsd[i]>0.4 or tcs[i]>0.2:
                       del(toWrite[n[i]]); del(tcs[i]); del(grmsd[i]); del(lrmsd[i]); del(pdbid[i]); i=i-1; L=L-1;
                 else:
                    if lrmsd[i]>0.9 or tcs[i]>0.4:
                       del(toWrite[n[i]]); del(tcs[i]); del(grmsd[i]); del(lrmsd[i]); del(pdbid[i]); i=i-1; L=L-1;
                 i=i+1

            ################ LIST XYZ COORDINATES TO REMOVE PROXIMAL-DOUBLE ADDITIONS ############
            if L>1:
                 xx=[]; yy=[]; zz=[]; de=[];
                 for i in range (n[0],n[L-1]+1) :
                       splt2=toWrite[i].split()
                       xx.append(float(splt2[10]))
                       yy.append(float(splt2[11]))
                       zz.append(float(splt2[12]))
                       f0=[]; f1=[]; f2=[];f3=[]; dx=[]; dy=[]; dz=[]; r=[];       ####create a matrix
                 for i in range(0,L):
                     for j in range(0,L):
                         f0.append(0); f1.append(-1); f2.append(-2); f3.append(-3)
                     dx.append(f0)
                     dy.append(f1)
                     dz.append(f2)
                     r.append(f3)
                     f0=[]; f1=[]; f2=[]; f3=[];
                 for i in range (0,L):
                     for j in range(i+1,L): ### no overlaps
                          dy[i][j]=yy[i] - yy[j]
                          dz[i][j]=zz[i] - zz[j]
                          dx[i][j]=xx[i] - xx[j]
                          r[i][j]=((dx[i][j]**2)+(dy[i][j]**2)+(dz[i][j]**2))**0.5 ### calculating distance
                          if r[i][j]>0 and r[i][j]<5:                             ### setting the maximum accepted distance between transplants
                             if pdbid[i]!=pdbid[j]:     ### if they originate from the same pdb, dont remove them, is alphafill doing the same?
                                if lrmsd[i]<lrmsd[j]:                             ### keeping the one with the best Lrmsd
                                   toWrite[n[j]]='#\n';
                                else :
                                     toWrite[n[i]]='#\n';
                 i=n[0]; L=i+L;
                 while i<L:
                       if toWrite[i]=='#\n' :
                          del(toWrite[i])                    ### remove the lines that were set as #, cz i couldn't delete them directly
                          i=i-1; L=L-1;
                       i=i+1
        if hemeLRMSD!=[]:
           for i in range (len(toWrite)):
               if (toWrite[i][0:6]=='HETATM' or toWrite[i][0:4]=='ATOM') and (toWrite[i+1][0:6]!= 'HETATM' or toWrite[i+1][0:4]!='ATOM'):
                  save=i;
           toWrite[save + 1:save + 1] = toWrite2         #add hemes
    d=open('./SimplyFilteredCifs/'+'Edited'+aflist[c]+'.cif','w')               ###save the filtered structure as cif
    d.writelines(toWrite)
    d.close()
    if mdata['hits']==None or (grmsd==[] and hemeLRMSD==[]):
       with pymol2.PyMOL() as pymol:
            pymol.cmd.load('./SimplyFilteredCifs/'+'Edited'+aflist[c]+'.cif')
            pymol.cmd.save('./NoHets/'+aflist[c]+'.pdb')            ##no het, just save as pdb, otherwise...
################ metal Neighbourhood, AA protonation ####################
    else:
        with pymol2.PyMOL() as pymol:
             pymol.cmd.load('./SimplyFilteredCifs/'+'Edited'+aflist[c]+'.cif')          
#################### remove ions that are not bound anywhere #################
             pymol.cmd.select('sele',"het and not resn HEM");
             pymol.cmd.do('ids = []')
             pymol.cmd.iterate('sele', 'ids.append(index)')
             ids=pymol.ids
             for i in range (len(ids)):
                 pymol.cmd.select('sele','index '+str(ids[i]))
                 Nmbr=pymol.cmd.select("nearbyAtoms", "sele around 3.4 and elem N+O+S")
                 if Nmbr<1:
                    pymol.cmd.remove('sele')
#################### HEME TIME #######################################
             if hemeAsymid!=[]:
                lH=len(hemeAsymid)
                i=0;
                while i<lH:
                    pymol.cmd.select('sele','chain '+hemeAsymid[i])
                    pymol.cmd.select("HEM_FE", "sele and name FE")
                    count=pymol.cmd.select("CHAIN_4A", "HEM_FE around 4 and elem N+O+S and Chain A")
                    if count<1:
                       pymol.cmd.remove('sele'); #remove hemes that aren't bound anywhere 
                       del(hemeLRMSD[i]); del(hemeAsymid[i]); del(hemeBlast[i]); del(hemeTCS[i]); i=i-1; lH=lH-1;
                    i=i+1
                lH2=len(hemeLRMSD);
                if lH2>0:
                   i=0
                   while i < lH2:
                       if hemeLRMSD[i]>1 and hemeTCS[i]<0.25: #remove heme if it has low confidence
                          pymol.cmd.select('sele','chain '+hemeAsymid[i])
                          pymol.cmd.remove('sele');
                          del(hemeLRMSD[i]); del(hemeAsymid[i]); del(hemeBlast[i]); del(hemeTCS[i]); i=i-1; lH2=lH2-1;
                       i=i+1
                   lH3=len(hemeLRMSD); i=0
                   while i<lH3:
                         pymol.cmd.select('sele1','chain '+hemeAsymid[i])
                         pymol.cmd.select('sele2', "sele1 around 3 and resn HEM")
                         pymol.cmd.do('asid = []')
                         pymol.cmd.iterate('sele2', 'asid.append(chain)')
                         asid=pymol.asid; asid=list(set(asid))
                         k=0
                         while k < (len(asid)):
                             ix=hemeAsymid.index(asid[k])
                             if hemeLRMSD[ix]<hemeLRMSD[i]:
                                pymol.cmd.remove('sele1'); # compare proximal hemes and remove the one with higher lrmsd
                                del(hemeLRMSD[i]); del(hemeAsymid[i]); del(hemeBlast[i]); del(hemeTCS[i]); i=i-1; lH3=lH3-1; k = len(asid)
                             else:
                                pymol.cmd.remove('chain '+asid[k]);
                                del(hemeLRMSD[ix]); del(hemeAsymid[ix]); del(hemeBlast[ix]); del(hemeTCS[ix]); lH3=lH3-1;
                             k=k+1
                         i=i+1
                   if len(hemeAsymid)>0:
                      pymol.cmd.do('jj=0')
                      for i in range (len(hemeAsymid)):
                          pymol.cmd.do('jj=jj+1')
                          pymol.cmd.select('sele','chain '+hemeAsymid[i])
                          pymol.cmd.load('heme.pdb');
                          pymol.cmd.set_name('heme','heme'+str(i))
                          pymol.cmd.align('heme'+str(i),'sele')
                          pymol.cmd.alter('heme'+str(i),'resi='+str(i))
                          ah=pymol.jj; print(str(i))
                          pymol.cmd.select("hetatoms_around", "het within 4 of sele")
                          pymol.cmd.select("hetatoms_exclude_hem", "hetatoms_around and not resn HEM")
                          pymol.cmd.remove("hetatoms_exclude_hem"); ### remove het close to heme
                          pymol.cmd.remove('sele');
             breik=pymol.cmd.select('het')            ### if no Hetatoms remain, break and save
             if breik == 0 :
                pymol.cmd.save('./NoHets/'+aflist[c]+'.pdb')
                pymol.cmd.reinitialize('everything')
             else :
                pymol.cmd.save('./fullyFiltered/'+aflist[c]+'.pdb')
######################## MAKING CYS -> CYM, to not protonate it #####################################
                pymol.cmd.select("sele","(hetatm around 4 & resn cys)") #to avoid cysteine protonation
                pymol.cmd.do('cysp = []')
                pymol.cmd.iterate('sele', 'cysp.append(resi)')
                pymol.cmd.do('cysp=set(cysp)');
                pymol.cmd.do('cysp=list(cysp)')
                cysp=pymol.cysp
                pymol.cmd.select('sele2', 'resn his + het')     #listing histidine nithrogens and hetatoms for later use
                pymol.cmd.select('Nitros','sele2 and name NE2+ND1 + het')
                pymol.cmd.save(aflist[c]+'_Nitr&het.pdb','Nitros')
                pymol.cmd.reinitialize('everything')
                f=open('./fullyFiltered/'+aflist[c]+'.pdb','r')
                rdl=f.readlines(); f.close()
                if len(cysp)>0:
                   for i in range (len(cysp)):
                       for j in range (len(rdl)):
                           if rdl[j][0:4]=='ATOM':
                              AAN=rdl[j].split()
                              if AAN[5]==str(int(cysp[i])):
                                 rdl[j]=rdl[j][0:17]+'CYM'+rdl[j][20:len(rdl[j])] #cys->cym

                f=open('0'+aflist[c]+'.pdb','w');
                for i in range(len(rdl)):
                    f.write(rdl[i])
                f.close()
####################### LOAD HIS FILE, CALCULATE DISTANCES AND CREATE A LIST FOF GROMacs #####
                pymol.cmd.load(aflist[c]+'_Nitr&het.pdb')
                pymol.cmd.select('het')
                Nhet=pymol.cmd.count_atoms('sele')
                pymol.cmd.select('resn his')
                Nhis=pymol.cmd.count_atoms('sele')
                listHis=[]; i=1
                while i<Nhis:
                    pymol.cmd.select('Nd', 'index '+ str(i))
                    pymol.cmd.select('Ne', 'index '+ str(i+1))
                    SdisE=0; SdisD=0;
                    for j in range (Nhis+1, Nhis+Nhet+1):
                        pymol.cmd.select('Metal', 'index '+ str(j))
                        disNE=pymol.cmd.distance('dis','Ne','Metal') # measuring distances
                        disND=pymol.cmd.distance('dis','Nd','Metal')
                        if disND<3: # 1 means dont protonate
                           SdisD=SdisD+1
                        if disNE<3:
                           SdisE=SdisE+1
                        if disNE<3 and disND<3: ## at least one must have a H
                           Df=disNE-disND       #protonate the one that has the greatest distance
                           if Df<0:
                              SdisD=SdisD-1
                           else:
                              SdisE=SdisE-1
                    if SdisE==0:
                       listHis.append('1 ')
                    else:
                       listHis.append('0 ')
                    i=i+2
                pymol.cmd.reinitialize('everything')
                f=open(aflist[c]+'listHis.txt','w');
                for i in range (len(listHis)):
                    f.write(str(listHis[i])) #this file will be read by gromacs for accurate protonation of histidines
                f.close();
                
 ############ For compatibility with Gromacs and Charmmff,name all het Chain B and Rename metal ions #######

                f=open('./fullyFiltered/'+aflist[c]+'.pdb','r')
                fix=f.readlines()
                f.close();
                j=1
                for i in range (len(fix)):
                    if fix[i][0:5]=='HETAT' and fix[i][17:20]!='HEM':
                       ss=str(j); l=len(fix[i])
                       fix[i]=fix[i][0:21]+'B   '+ss+fix[i][26:l]   #name all chain B
                       q = fix[i][18:20]
                       if q=="CO" or q=="MN" or q=="FE" or q=="NI" or q=="CU":
                          fix[i]=fix[i][0:14]+'2P '+q+'2PJ'+fix[i][22:len(fix[i])]
                       elif q==' K':
                          fix[i]=fix[i][0:12]+'POT  POT K'+fix[i][22:len(fix[i])]
                       elif q=='CA':
                          fix[i]=fix[i][0:12]+'CAL  CAL L'+fix[i][22:len(fix[i])]
                       j=j+1
                    if fix[i][0:5]=='HETAT' and fix[i][17:20]=='HEM':
                       l=len(fix[i])
                       fix[i]=fix[i][0:21]+'C   '+fix[i][25:l]   #name all chain C for heme
                f=open('0'+aflist[c]+'.pdb','w');
                for u in range (len(fix)):
                    f.write(fix[u]);
                f.close()
                f=open('name4gromcs.txt','w'); f.write(aflist[c]); f.close()

                ## run the Bash script for energy minimization as a subprocess
                subprocess.run(['bash', 'gromin.sh'])
                ## Remove waters and net zero ions added by gromacs
                with pymol2.PyMOL() as pymol:
                     pymol.cmd.load(aflist[c]+'.gro')
                     pymol.cmd.set_name(aflist[c],'gros')
                     pymol.cmd.load('0'+aflist[c]+'.pdb')
                     pymol.cmd.set_name('0'+aflist[c],'pdbss')
                     pymol.cmd.remove('resn SOL')
                     pymol.cmd.remove('resn CL')
                     pymol.cmd.align('gros','pdbss')
                     pymol.cmd.remove('pdbss')
                     pymol.cmd.select('resn NA')
                     pymol.cmd.do('ids = []')
                     pymol.cmd.iterate('sele', 'ids.append(index)')
                     ids=pymol.ids
                     for i in range (len(ids)):
                         pymol.cmd.select('sele','index '+str(ids[i]))
                         Nmbr=pymol.cmd.select("nearbyAtoms", "sele around 3.4 and elem N+O+S")
                         if Nmbr<1:
                            pymol.cmd.remove('sele')
                     pymol.cmd.set_name('gros',aflist[c])
                     pymol.cmd.save('./MinimizedStructurePDB/'+'EM_'+aflist[c]+'.pdb')
                     pymol.cmd.reinitialize('everything')
