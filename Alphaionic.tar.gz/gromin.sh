#!/bin/bash

# create an empty array to store the lines
#line=("AF-P31151-F1")
rm -r *.gro

filename="name4gromcs.txt"
while read -r line; do
  line+=("$line")
done < "$filename"

echo $line
for line in "${line[@]}"; do
  oo=$(cat "$line"listHis.txt)
  echo $oo "1 1" |gmx pdb2gmx -f 0"$line".pdb -o "$line".gro -ignh -ff charmm2022 -water tip3p -his -ter -missing
  gmx editconf -f "$line".gro -o "$line".gro -c -d 1.5 -bt cubic
  gmx solvate -cp "$line".gro -cs spc216.gro -o "$line".gro -p topol.top
  gmx grompp -f ions.mdp -c "$line".gro -p topol.top -o ions.tpr
  echo SOL |gmx genion -s ions.tpr -o "$line".gro -p topol.top -pname NA -nname CL -neutral
  gmx grompp -f minim.mdp -c "$line".gro -p topol.top -o "$line".tpr -maxwarn 1
  gmx mdrun -v -deffnm "$line"
  rm -- '#'*
  rm -r *.itp
  rm -r *.trr
  rm -r *.tpr
  rm -r *.edr
  rm "$line"_Nitr'&'het.pdb
  rm "$line"listHis.txt
done
