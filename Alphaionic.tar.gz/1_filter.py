import urllib.request
from urllib.request import urlopen
import json
aflist=input('alphafold id: ')

####### READ THE CIF, download from afill db #######

fo = urllib.request.urlopen('https://alphafill.eu/v1/aff/'+aflist).read().decode('utf-8')
d=open(aflist+'.cif','w')
d.write(fo)
d.close()
f=open(aflist+'.cif','r');
line = fo.readlines()
f.close();
######## READ THE JSON METADATA, afill db ##########

url = 'https://alphafill.eu/v1/aff/'+aflist+'/json'
with urlopen(url) as response:
     body = response.read()
mdata = json.loads(body)

###### IF NO HETATAOMS, DOWNLOAD ONLY ######

if mdata['hits']!=None:
    l=len(line); i=0; toWrite=[]; n=[]; ii=0; heme=[]; indx=[]
    while i<l :
          if line[i][0:6]!="HETATM":
             toWrite.append(line[i])
          else:
                indx.append(i)
                splt=line[i].split(); s=splt[5]   ######### KEEP ONLY THE ATOMS THAT ARE ONE OF THESE METALS or heme ###############
                if s=="ZN" or s=="FE" or s=="NA" or s=="MG" or s=="CU" or s=="K" or s=="CA" or s=="MN" or s=="CO" or s=="NI": #naturally found metals, catalytic or structural significance
                   toWrite.append(line[i]); n.append(i-ii)
                elif s=='HEM':
                   heme.append(lines[i]); ii=ii+1
                else:
                      ii=ii+1
          i=i+1
    l1=len(mdata['hits'])
    grmsd=[]; lrmsd=[]; pdbid=[]; tcs=[]; homol=[]; hemeLRMSD=[]; hemeBlast=[]; hemeAsymid=[]; ##hemeGRMSD=[]; hemeTCS=[];
    for i in range (0,l1):
        l2=len(mdata['hits'][i]['transplants'])
        for j in range (0,l2):
            cN=mdata['hits'][i]['transplants'][j]['compound_id']   ###### LIST THE SCORES, BLAST, VDWls, RMSDs ########
            if cN=='ZN' or cN=='NA' or cN=='FE' or cN=='MG' or cN=='K' or cN=='NI' or cN=='MN' or cN=='CU' or cN=='CA' or cN=='CO':
               grmsd.append(mdata['hits'][i]['rmsd'])
               homol.append(mdata['hits'][i]['identity'])
               lrmsd.append(mdata['hits'][i]['transplants'][j]['rmsd'])
               pdbid.append(mdata['hits'][i]['pdb_id'])
               tcs.append(mdata['hits'][i]['transplants'][j]['clash']['score'])
            if cN=='HEM':
               #hemeTCS.append(mdata['hits'][i]['transplants'][j]['clash']['score'])
               hemeLRMSD.append(mdata['hits'][i]['transplants'][j]['rmsd'])
               #hemeGRMSD.append(mdata['hits'][i]['rmsd'])
               hemeBlast.append(mdata['hits'][i]['identity'])
               hemeAsymid.append(mdata['hits'][i]['transplants'][j]['asym_id'])
    heme2=[]
    if hemeLRMSD!=[]:
       bestHeme=min(hemeLRMSD); ### not a good filter for double addition from multimers, need pymol to remove !!!!!!!!!!!!! AF-A0A159JYF7-F1-model_v4
       index=hemeLRMSD.index(bestHeme)
       if bestHeme<0.3 or (hemeBlast[index]>0.7 and bestHeme<0.9):   #high homology -> less strict local rmsd
          for i in range (len(heme)):
              splt2=heme[i].split();
              if splt2[6] == hemeAsymid[index]:
                 heme2.append(heme[i])

    if grmsd!=[]:
        L=len(grmsd); i=0;
        while i<L:                                ########## THRESHOLDS TO RETAIN ONLY CONFIDENT ADDITIONS ############
             if homol[i]<0.7 or grmsd[i]>0.5:
                if lrmsd[i]>0.4 or tcs[i]>0.2:
                   del(toWrite[n[i]]); del(tcs[i]); del(grmsd[i]); del(lrmsd[i]); del(pdbid[i]); i=i-1; L=L-1;
             else:
                 if lrmsd[i]>0.9 or tcs[i]>0.4:
                    del(toWrite[n[i]]); del(tcs[i]); del(grmsd[i]); del(lrmsd[i]); del(pdbid[i]); i=i-1; L=L-1;
             i=i+1

        ################ LIST XYZ COORDINATES TO REMOVE PROXIMAL-DOUBLE ADDITIONS ############
        if L>1:
              xx=[]; yy=[]; zz=[]; de=[];
              for i in range (n[0],n[L-1]+1) :
                    splt2=toWrite[i].split()
                    xx.append(float(splt2[10]))
                    yy.append(float(splt2[11]))
                    zz.append(float(splt2[12]))
              f0=[]; f1=[]; f2=[];f3=[]; dx=[]; dy=[]; dz=[]; r=[];       #### create a matrix
              for i in range(0,L):
                  for j in range(0,L):
                      f0.append(0); f1.append(-1); f2.append(-2); f3.append(-3)
                  dx.append(f0)
                  dy.append(f1)
                  dz.append(f2)
                  r.append(f3)
                  f0=[]; f1=[]; f2=[]; f3=[];

              for i in range (0,L):
                  for j in range(i+1,L):         ### no overlaps
                      dy[i][j]=yy[i] - yy[j]
                      dz[i][j]=zz[i] - zz[j]
                      dx[i][j]=xx[i] - xx[j]
                      r[i][j]=((dx[i][j]**2)+(dy[i][j]**2)+(dz[i][j]**2))**0.5       ### calculating distance
                      if r[i][j]>0 and r[i][j]<5:                        ### setting the maximum accepted distance between transplants
                         if pdbid[i]!=pdbid[j]:                                      ### if they originate from the same pdb, dont remove them
                            if lrmsd[i]<lrmsd[j]:                        ### keeping the one with the best Lrmsd
                               toWrite[n[j]]='#\n';
                            else :
                                 toWrite[n[i]]='#\n';
              i=n[0]; L=i+L;
              while i<L:                                                ### remove the lines that were set as #, cz i couldn't delete them directly
                    if toWrite[i]=='#\n' :
                       del(toWrite[i])
                       i=i-1; L=L-1;
                    i=i+1
    if heme2!=[]:
       for i in range(len(heme2)):
                toWrite.insert(indx[0] +i, heme2[i])                    ### add heme, no removal of metals close to heme
    d=open('Edited'+aflist+'.cif','w')                                ### save the filtered structure as cif
    for i in range(len(toWrite)):
        d.write(toWrite[i]+'\n')
    d.close()
